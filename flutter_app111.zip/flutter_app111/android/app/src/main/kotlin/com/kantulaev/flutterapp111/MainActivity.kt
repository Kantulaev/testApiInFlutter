package com.kantulaev.flutterapp111

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
